import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { HeroSection } from "@/components/HeroSection";
import { FeaturesSection } from "@/components/FeaturesSection";
import { AnalysisForm } from "@/components/AnalysisForm";
import { ResultDisplay } from "@/components/ResultDisplay";
import type { DetectionResult } from "@/lib/reviewDetector";
import { motion, AnimatePresence } from "framer-motion";
import { useTranslation } from "react-i18next";

const Dashboard = () => {
  const [result, setResult] = useState<DetectionResult | null>(null);
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <FeaturesSection />
      <AnimatePresence mode="wait">
        {result ? (
          <motion.div key="result" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -30 }} transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}>
            <ResultDisplay result={result} onReset={() => setResult(null)} />
          </motion.div>
        ) : (
          <motion.div key="form" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -30 }} transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}>
            <AnalysisForm onResult={setResult} />
          </motion.div>
        )}
      </AnimatePresence>
      <motion.footer className="border-t border-border/30 py-10 text-center relative overflow-hidden"
        initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ duration: 0.6 }}>
        <div className="absolute inset-0 bg-gradient-to-t from-primary/2 to-transparent" />
        <p className="text-sm text-muted-foreground/60 font-display relative z-10">
          © 2026 <span className="text-muted-foreground">ReviewGuard</span> — {t('hero.badge')}
        </p>
      </motion.footer>
    </div>
  );
};

export default Dashboard;
