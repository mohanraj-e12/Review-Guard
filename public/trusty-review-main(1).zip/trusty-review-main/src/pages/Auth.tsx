import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ShieldCheck, Mail, Lock, User, Loader2, ArrowRight, Sparkles } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { motion, AnimatePresence } from "framer-motion";
import { useTranslation } from "react-i18next";

const Auth = () => {
  const [mode, setMode] = useState<"login" | "signup" | "forgot">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  const { t } = useTranslation();

  useEffect(() => {
    if (user) navigate("/dashboard", { replace: true });
  }, [user, navigate]);

  const handleGoogleSignIn = async () => {
    const { error } = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (error) {
      toast({ title: t('auth.error'), description: String(error), variant: "destructive" });
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    const normalizedEmail = email.trim().toLowerCase();
    if (!normalizedEmail) return;
    setLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(normalizedEmail, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) throw error;
      toast({ title: t('auth.emailSent'), description: t('auth.checkInbox') });
      setMode("login");
    } catch (error: any) {
      toast({ title: t('auth.error'), description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === "forgot") return handleForgotPassword(e);

    const normalizedEmail = email.trim().toLowerCase();
    const normalizedPassword = password.trim();
    if (!normalizedEmail || !normalizedPassword) return;
    setLoading(true);

    try {
      if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({
          email: normalizedEmail, password: normalizedPassword,
        });
        if (error) {
          if (error.message.toLowerCase().includes("invalid login credentials")) {
            toast({ title: t('auth.invalidCredentials'), description: t('auth.invalidCredentialsDesc'), variant: "destructive" });
            return;
          }
          throw error;
        }
        navigate("/dashboard", { replace: true });
      } else {
        if (!displayName.trim()) {
          toast({ title: t('auth.error'), description: t('auth.enterName'), variant: "destructive" });
          return;
        }
        const { data, error } = await supabase.auth.signUp({
          email: normalizedEmail, password: normalizedPassword,
          options: { data: { display_name: displayName.trim() }, emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        if (data.session) { navigate("/dashboard", { replace: true }); return; }
        toast({ title: t('auth.accountCreated'), description: t('auth.accountCreatedDesc') });
        setMode("login");
      }
    } catch (error: any) {
      toast({ title: t('auth.error'), description: error.message || "Something went wrong", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const headingText = mode === "login" ? t('auth.signInSubtitle') : mode === "signup" ? t('auth.signUpSubtitle') : t('auth.resetSubtitle');
  const buttonText = mode === "login" ? t('auth.signIn') : mode === "signup" ? t('auth.createAccount') : t('auth.sendResetLink');

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 opacity-[0.03]">
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(hsl(160 84% 39% / 0.5) 1px, transparent 1px), linear-gradient(90deg, hsl(185 80% 50% / 0.3) 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }} />
      </div>

      <motion.div className="absolute top-1/4 left-1/4 w-72 h-72 rounded-full bg-primary/5 blur-[120px]"
        animate={{ y: [0, -20, 10, 0], x: [0, 10, -5, 0] }} transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }} />
      <motion.div className="absolute bottom-1/4 right-1/4 w-56 h-56 rounded-full bg-cyan/5 blur-[100px]"
        animate={{ y: [0, 15, -10, 0], x: [0, -15, 5, 0] }} transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 1 }} />
      <motion.div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-fake/3 blur-[130px]"
        animate={{ scale: [1, 1.15, 1], opacity: [0.3, 0.5, 0.3] }} transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 2 }} />

      <motion.div className="w-full max-w-md relative z-10"
        initial={{ opacity: 0, y: 30, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}>
        <motion.div className="text-center mb-8" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15, duration: 0.5 }}>
          <motion.div className="inline-flex items-center gap-2 mb-5" whileHover={{ scale: 1.05 }} transition={{ type: "spring", stiffness: 300 }}>
            <div className="relative w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center group hover:bg-primary/20 transition-all duration-300 hover:shadow-[0_0_30px_hsl(160_84%_39%/0.2)]">
              <ShieldCheck className="w-8 h-8 text-primary transition-transform duration-300 group-hover:scale-110" />
            </div>
          </motion.div>
          <h1 className="font-display text-3xl font-bold mb-1">
            Review<span className="text-gradient-cyan">Guard</span>
          </h1>
          <AnimatePresence mode="wait">
            <motion.p key={mode} className="text-muted-foreground text-sm mt-2"
              initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }} transition={{ duration: 0.2 }}>
              {headingText}
            </motion.p>
          </AnimatePresence>
        </motion.div>

        <motion.div className="card-glass rounded-2xl border border-border/50 p-8 border-gradient"
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25, duration: 0.5 }}>
          {mode !== "forgot" && (
            <>
              <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                <Button type="button" variant="outline" onClick={handleGoogleSignIn}
                  className="w-full h-12 mb-4 font-medium border-border/50 hover:bg-secondary/80 hover:border-primary/20 transition-all duration-300 rounded-xl">
                  <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4" />
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
                  </svg>
                  {t('auth.continueGoogle')}
                </Button>
              </motion.div>
              <div className="relative mb-4">
                <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-border/50" /></div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-card/80 backdrop-blur-sm px-3 text-muted-foreground font-display tracking-wider">{t('auth.or')}</span>
                </div>
              </div>
            </>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <AnimatePresence mode="wait">
              {mode === "signup" && (
                <motion.div key="name" className="space-y-2" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.3 }}>
                  <Label htmlFor="name" className="text-sm font-medium flex items-center gap-2 text-muted-foreground">
                    <User className="w-4 h-4" /> {t('auth.displayName')}
                  </Label>
                  <Input id="name" type="text" placeholder={t('auth.namePlaceholder')} value={displayName} onChange={(e) => setDisplayName(e.target.value)}
                    className="h-12 bg-secondary/50 border-border/50 focus:border-primary/50 focus:shadow-[0_0_15px_hsl(160_84%_39%/0.1)] transition-all duration-300 rounded-xl" />
                </motion.div>
              )}
            </AnimatePresence>

            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium flex items-center gap-2 text-muted-foreground">
                <Mail className="w-4 h-4" /> {t('auth.email')}
              </Label>
              <Input id="email" type="email" placeholder={t('auth.emailPlaceholder')} value={email} onChange={(e) => setEmail(e.target.value)} required
                className="h-12 bg-secondary/50 border-border/50 focus:border-primary/50 focus:shadow-[0_0_15px_hsl(160_84%_39%/0.1)] transition-all duration-300 rounded-xl" />
            </div>

            <AnimatePresence mode="wait">
              {mode !== "forgot" && (
                <motion.div key="password" className="space-y-2" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.3 }}>
                  <Label htmlFor="password" className="text-sm font-medium flex items-center gap-2 text-muted-foreground">
                    <Lock className="w-4 h-4" /> {t('auth.password')}
                  </Label>
                  <Input id="password" type="password" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6}
                    className="h-12 bg-secondary/50 border-border/50 focus:border-primary/50 focus:shadow-[0_0_15px_hsl(160_84%_39%/0.1)] transition-all duration-300 rounded-xl" />
                </motion.div>
              )}
            </AnimatePresence>

            {mode === "login" && (
              <div className="text-right">
                <button type="button" onClick={() => setMode("forgot")} className="text-xs text-primary/70 hover:text-primary transition-colors duration-200">
                  {t('auth.forgotPassword')}
                </button>
              </div>
            )}

            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button type="submit" disabled={loading}
                className="w-full h-13 font-display font-semibold bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-300 rounded-xl hover:shadow-[0_0_30px_hsl(160_84%_39%/0.3)] relative overflow-hidden group">
                {loading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
                    {buttonText}
                    <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform duration-300" />
                  </>
                )}
              </Button>
            </motion.div>
          </form>

          <div className="mt-6 text-center">
            {mode === "forgot" ? (
              <button type="button" onClick={() => setMode("login")} className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">
                {t('auth.backToSignIn')} <span className="text-primary font-medium">{t('auth.signIn')}</span>
              </button>
            ) : (
              <button type="button" onClick={() => setMode(mode === "login" ? "signup" : "login")} className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">
                {mode === "login" ? t('auth.noAccount') : t('auth.haveAccount')}
                <span className="text-primary font-medium">{mode === "login" ? t('auth.signUp') : t('auth.signIn')}</span>
              </button>
            )}
          </div>
        </motion.div>

        <motion.p className="text-center text-[10px] text-muted-foreground/50 mt-6 font-display"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }}>
          {t('auth.protectedBy')}
        </motion.p>
      </motion.div>
    </div>
  );
};

export default Auth;
