import { ShieldCheck, Zap } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { motion } from "framer-motion";
import { SettingsSheet } from "@/components/SettingsSheet";
import { useTranslation } from "react-i18next";

export function Navbar() {
  const { user } = useAuth();
  const { t } = useTranslation();

  return (
    <motion.nav
      className="border-b border-border/50 bg-background/60 backdrop-blur-xl sticky top-0 z-50"
      initial={{ y: -60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] }}
    >
      <div className="container max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <motion.a
          href="#"
          className="flex items-center gap-2.5 group"
          whileHover={{ scale: 1.03 }}
          transition={{ type: "spring", stiffness: 400, damping: 20 }}
        >
          <div className="relative w-9 h-9 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center group-hover:bg-primary/20 transition-all duration-300 group-hover:shadow-[0_0_20px_hsl(160_84%_39%/0.2)]">
            <ShieldCheck className="w-5 h-5 text-primary transition-transform duration-300 group-hover:scale-110" />
            <div className="absolute inset-0 rounded-xl animate-pulse-ring border border-primary/20 opacity-0 group-hover:opacity-100" />
          </div>
          <div className="flex items-center gap-1.5">
            <span className="font-display font-bold text-lg tracking-tight">Review</span>
            <span className="font-display font-bold text-lg text-gradient-cyan tracking-tight">Guard</span>
          </div>
        </motion.a>

        <div className="flex items-center gap-3">
          <motion.a
            href="#analyze"
            className="hidden sm:flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors duration-200 px-3 py-1.5 rounded-lg hover:bg-primary/5"
            whileHover={{ y: -1 }}
            whileTap={{ scale: 0.97 }}
          >
            <Zap className="w-3.5 h-3.5" />
            {t('nav.analyze')}
          </motion.a>
          {user && (
            <motion.div
              className="flex items-center gap-2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3, duration: 0.4 }}
            >
              <SettingsSheet />
            </motion.div>
          )}
        </div>
      </div>
    </motion.nav>
  );
}
